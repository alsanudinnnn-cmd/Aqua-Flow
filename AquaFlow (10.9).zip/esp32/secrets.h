#pragma once

// Deprecated: smart_water_monitor.ino now contains the inline configuration.
// This file is intentionally empty and is not included by the firmware.
