# Firebase setup

1. Create a Firebase project and register a Web app.
2. Create a Realtime Database in the Singapore region when available.
3. Enable **Authentication → Sign-in method → Anonymous** for the dashboard and ESP32.
4. Replace the placeholder values in `assets/js/firebase-config.js` with the Web app configuration.
5. In Realtime Database, open **Rules**, paste `firebase/database.rules.json`, and publish it.
6. Optionally import `firebase/sample-data.json` from the Realtime Database data screen.

The public Firebase web configuration is not a service-account credential. Never upload a service-account JSON file, private key, Wi-Fi password, Telegram bot token, or refresh token to InfinityFree.

Expected ESP32 reading structure:

```json
{
  "device_id": "esp32-water-01",
  "sensor_name": "YF-S201",
  "flow_rate": 4.25,
  "water_usage": 120.35,
  "monthly_litres": 48.20,
  "baseline_flow_rate": 4.10,
  "flow_drop_ratio": 0.35,
  "leakage_status": "Normal",
  "timestamp": 1787805145000
}
```

Push each reading beneath `/readings` using a unique Firebase key. The dashboard listens to the latest 2,000 readings in timestamp order.

The firmware in `esp32/smart_water_monitor.ino` signs in anonymously, pushes readings to
`/readings`, and writes one record beneath `/alerts` when continuous flow crosses the
configured leakage duration. Anonymous auth is convenient for prototypes; use stricter writer
rules before production.
