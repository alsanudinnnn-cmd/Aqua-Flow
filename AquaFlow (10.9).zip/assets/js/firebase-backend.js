const config = window.SMART_WATER_FIREBASE_CONFIG || {};
const requiredKeys = ['apiKey', 'authDomain', 'databaseURL', 'projectId', 'appId'];
const configured = requiredKeys.every(key => config[key] && !String(config[key]).includes('REPLACE_WITH'));

window.smartWaterFirebaseState = { configured, connected: false, source: configured ? 'firebase' : 'mock' };

function emit(name, detail) {
  window.dispatchEvent(new CustomEvent(name, { detail }));
}

if (!configured) {
  emit('smartwater:firebase-status', {
    configured: false,
    connected: false,
    message: 'Firebase configuration required'
  });
} else {
  connectFirebase().catch(error => {
    window.smartWaterFirebaseState.connected = false;
    emit('smartwater:firebase-status', {
      configured: true,
      connected: false,
      message: error?.message || 'Unable to connect to Firebase'
    });
  });
}

async function connectFirebase() {
  const version = '12.18.0';
  const appSdk = await import(`https://www.gstatic.com/firebasejs/${version}/firebase-app.js`);
  const authSdk = await import(`https://www.gstatic.com/firebasejs/${version}/firebase-auth.js`);
  const databaseSdk = await import(`https://www.gstatic.com/firebasejs/${version}/firebase-database.js`);

  const app = appSdk.initializeApp(config);
  const auth = authSdk.getAuth(app);
  const database = databaseSdk.getDatabase(app);
  await authSdk.signInAnonymously(auth);

  const connectedRef = databaseSdk.ref(database, '.info/connected');
  databaseSdk.onValue(connectedRef, snapshot => {
    const connected = snapshot.val() === true;
    window.smartWaterFirebaseState.connected = connected;
    emit('smartwater:firebase-status', {
      configured: true,
      connected,
      message: connected ? 'Firebase synchronized' : 'Firebase reconnecting'
    });
  });

  const readingsRef = databaseSdk.query(
    databaseSdk.ref(database, 'readings'),
    databaseSdk.orderByChild('timestamp'),
    databaseSdk.limitToLast(2000)
  );

  databaseSdk.onValue(readingsRef, snapshot => {
    const raw = snapshot.val() || {};
    const records = Object.entries(raw).map(([id, value]) => ({ id, ...value }));
    emit('smartwater:firebase-readings', { records });
  }, error => emit('smartwater:firebase-status', {
    configured: true,
    connected: false,
    message: `Read denied: ${error.message}`
  }));

  const alertsRef = databaseSdk.query(
    databaseSdk.ref(database, 'alerts'),
    databaseSdk.orderByChild('started_at'),
    databaseSdk.limitToLast(50)
  );

  databaseSdk.onValue(alertsRef, snapshot => {
    const raw = snapshot.val() || {};
    const records = Object.entries(raw).map(([id, value]) => ({ id, ...value }));
    emit('smartwater:firebase-alerts', { records });
  }, error => emit('smartwater:firebase-status', {
    configured: true,
    connected: false,
    message: `Alert read denied: ${error.message}`
  }));
}
