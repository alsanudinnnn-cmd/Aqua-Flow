(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const fmt = new Intl.NumberFormat('en-MY', { maximumFractionDigits: 1, minimumFractionDigits: 1 });
  const pad = value => String(value).padStart(2, '0');
  const now = new Date('2026-08-27T14:32:25+08:00');
  let virtualNow = new Date(now);
  let secondsSinceReading = 2;
  let currentFlow = 4.25;
  let todayUsage = 125.6;
  let monthUsage = 2845.7;
  let currentPage = 1;
  let sortDirection = 'desc';
  let toastTimer;
  let dataSource = 'mock';
  let streamPaused = false;
  let pendingUsageReset = null;
  let usageModalTrigger = null;
  let latestFirebaseUsage = null;
  const pageSize = 8;

  const usageResetStorageKey = 'smartWaterUsageResets';
  let usageResetState = (() => {
    try {
      return Object.assign({ today: null, month: null }, JSON.parse(localStorage.getItem(usageResetStorageKey) || '{}'));
    } catch (error) {
      return { today: null, month: null };
    }
  })();

  const settings = Object.assign({ threshold: 1, duration: 10, detection: true, alerts: true }, JSON.parse(localStorage.getItem('smartWaterSettings') || '{}'));
  const flowSeries = Array.from({ length: 48 }, (_, i) => {
    const wave = Math.sin(i / 3.8) * .72 + Math.sin(i / 1.7) * .25;
    return Math.max(0, +(3.6 + wave + (i > 31 && i < 38 ? .8 : 0)).toFixed(2));
  });
  flowSeries[flowSeries.length - 1] = currentFlow;

  const dailyData = [120, 145, 98, 160, 135, 112, 125.6];
  const monthlyData = [2450, 2780, 2620, 3010, 2890, 3150, 2965, 2845.7];
  const weeklyData = [780, 846, 814, 902, 876, 824, 801, 794];

  const statuses = ['Normal', 'Normal', 'Normal', 'Warning', 'Normal', 'Normal', 'Possible Leakage'];
  const readings = Array.from({ length: 64 }, (_, i) => {
    const stamp = new Date(now.getTime() - i * 60000);
    const leak = i === 17 || i === 18;
    const warning = i === 3 || i === 25 || i === 40;
    const flow = leak ? 5.2 + (i % 2) * .18 : warning ? 5.1 : Math.max(0, 3.1 + Math.sin(i / 2.6) * 1.12 + (i % 5) * .07);
    return {
      id: 1000 - i,
      sensor: 'YF-S201',
      timestamp: stamp,
      date: `${pad(stamp.getDate())}/${pad(stamp.getMonth() + 1)}/${stamp.getFullYear()}`,
      isoDate: `${stamp.getFullYear()}-${pad(stamp.getMonth() + 1)}-${pad(stamp.getDate())}`,
      time: `${pad(stamp.getHours())}:${pad(stamp.getMinutes())}:${pad(stamp.getSeconds())}`,
      flow: +flow.toFixed(2),
      usage: +(flow / 1.65).toFixed(1),
      status: leak ? 'Possible Leakage' : warning ? 'Warning' : 'Normal'
    };
  });

  const alerts = [
    { date: '26/08/2026', start: '02:14:08', end: '02:32:21', duration: '18 min 13 sec', loss: '93.6 L', status: 'Needs review', severity: 'critical' },
    { date: '19/08/2026', start: '17:42:10', end: '17:49:51', duration: '7 min 41 sec', loss: '31.2 L', status: 'Resolved', severity: 'warning' },
    { date: '08/08/2026', start: '04:08:33', end: '04:21:05', duration: '12 min 32 sec', loss: '58.7 L', status: 'Resolved', severity: 'warning' },
    { date: '29/07/2026', start: '23:54:02', end: '00:09:46', duration: '15 min 44 sec', loss: '72.4 L', status: 'Resolved', severity: 'warning' }
  ];

  function svgIcon(id) {
    return `<svg aria-hidden="true"><use href="#${id}"/></svg>`;
  }

  function statusBadge(status) {
    const cls = status === 'Normal' || status === 'Resolved' ? 'normal' : status === 'Warning' ? 'warning' : 'critical';
    return `<span class="status-badge ${cls}">${status}</span>`;
  }

  function updateNavAlertCount() {
    const badge = $('#navAlertCount');
    if (!badge) return;
    const activeCount = alerts.filter(alert => alert.status === 'Needs review' || alert.status === 'Active').length;
    badge.textContent = String(activeCount);
    badge.hidden = activeCount === 0;
    const reviewBadge = $('#alertsNeedsReview');
    if (reviewBadge) {
      reviewBadge.textContent = activeCount ? `${activeCount} needs review` : 'No active alerts';
      reviewBadge.className = `status-badge ${activeCount ? 'warning' : 'normal'}`;
    }
  }

  function applyLeakageStatus(status) {
    const normalized = status === 'Possible Leakage' ? 'critical' : status === 'Warning' ? 'warning' : 'normal';
    const label = normalized === 'critical' ? 'FLOW DROP DETECTED' : normalized === 'warning' ? 'FLOW DROP WARNING' : 'SYSTEM NORMAL';
    const message = normalized === 'critical'
      ? 'Flow has dropped sharply from the learned baseline.'
      : normalized === 'warning'
        ? 'Flow is trending sharply below the learned baseline.'
        : 'No drastic flow drop detected.';
    $('#systemBadge').className = `status-badge ${normalized}`;
    $('#systemBadge').textContent = normalized === 'critical' ? 'Possible drop' : normalized === 'warning' ? 'Watch' : 'Normal';
    $('#leakageLabel').textContent = label;
    $('#leakageMessage').textContent = message;
    $('#leakHero').className = `leak-hero ${normalized}`;
    $('#leakHeroTitle').textContent = label;
    $('#leakHeroText').textContent = message;
  }

  function showToast(message) {
    const toast = $('#toast');
    $('span', toast).textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 3500);
  }

  function persistUsageResets() {
    localStorage.setItem(usageResetStorageKey, JSON.stringify(usageResetState));
  }

  function usageTargetLabel(target) {
    return target === 'month' ? 'monthly' : 'today\'s';
  }

  function usageTargetValue(target) {
    return target === 'month' ? monthUsage : todayUsage;
  }

  function updateUsageMeta() {
    const todayMeta = $('#todayUsageMeta');
    const monthMeta = $('#monthUsageMeta');
    const isFirebaseData = dataSource === 'firebase';
    if (todayMeta) todayMeta.textContent = isFirebaseData && usageResetState.today?.manual ? 'Since last reset' : 'Since midnight';
    if (monthMeta) monthMeta.textContent = isFirebaseData && usageResetState.month?.manual ? 'Since last reset' : 'This month';
  }

  function updateUsageDisplay() {
    $('#todayUsage').textContent = fmt.format(Math.max(0, todayUsage));
    $('#monthUsage').textContent = fmt.format(Math.max(0, monthUsage));
    const dailyPct = Math.min(100, Math.max(0, todayUsage) / 180 * 100);
    $('#dailyPercent').textContent = `${dailyPct.toFixed(1)}%`;
    $('.mini-progress span').style.width = `${dailyPct}%`;
    updateUsageMeta();
  }

  function openUsageResetModal(target, trigger) {
    pendingUsageReset = target;
    usageModalTrigger = trigger;
    const modal = $('#usageResetModal');
    $('#usageModalTitle').textContent = `Reset ${usageTargetLabel(target)} total?`;
    $('#usageModalDescription').textContent = target === 'month'
      ? 'This starts a new monthly baseline for the dashboard. Your Firebase sensor history will stay intact.'
      : 'This starts a new daily baseline for the dashboard. Your Firebase sensor history will stay intact.';
    $('#usageModalValue').textContent = `${fmt.format(usageTargetValue(target))} L`;
    modal.hidden = false;
    document.body.classList.add('modal-open');
    requestAnimationFrame(() => $('#usageModalConfirm').focus());
  }

  function closeUsageResetModal() {
    const modal = $('#usageResetModal');
    if (modal.hidden) return;
    modal.hidden = true;
    document.body.classList.remove('modal-open');
    pendingUsageReset = null;
    if (usageModalTrigger) usageModalTrigger.focus();
    usageModalTrigger = null;
  }

  function confirmUsageReset() {
    if (!pendingUsageReset) return;
    const target = pendingUsageReset;
    if (dataSource === 'firebase' && latestFirebaseUsage) {
      if (target === 'month') {
        usageResetState.month = { key: latestFirebaseUsage.monthKey, raw: latestFirebaseUsage.rawMonthly, manual: true };
        monthUsage = 0;
      } else {
        usageResetState.today = { date: latestFirebaseUsage.dayKey, raw: latestFirebaseUsage.rawTotal, manual: true };
        todayUsage = 0;
      }
    } else {
      if (target === 'month') monthUsage = 0;
      else todayUsage = 0;
    }
    persistUsageResets();
    dailyData[dailyData.length - 1] = todayUsage;
    monthlyData[monthlyData.length - 1] = monthUsage;
    updateUsageDisplay();
    drawAllCharts();
    closeUsageResetModal();
    showToast(`${target === 'month' ? 'Monthly' : 'Today\'s'} usage counter reset.`);
  }

  function setupUsageResets() {
    $$('[data-reset-target]').forEach(button => button.addEventListener('click', () => openUsageResetModal(button.dataset.resetTarget, button)));
    $('#usageModalConfirm').addEventListener('click', confirmUsageReset);
    $('#usageModalCancel').addEventListener('click', closeUsageResetModal);
    $('#usageModalClose').addEventListener('click', closeUsageResetModal);
    $$('[data-usage-modal-close]').forEach(item => item.addEventListener('click', closeUsageResetModal));
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && !$('#usageResetModal').hidden) closeUsageResetModal();
    });
  }

  function navigate(viewName, updateUrl = true) {
    const view = $(`[data-page="${viewName}"]`);
    if (!view) return;
    $$('.view').forEach(item => item.classList.toggle('active', item === view));
    $$('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.view === viewName));
    const title = $('.nav-item.active span:nth-child(2)')?.textContent || 'Smart Water Monitoring';
    $('#pageTitle').textContent = viewName === 'dashboard' ? 'Water observatory' : title;
    document.title = `${title} · AquaSense`;
    if (updateUrl) history.replaceState(null, '', `#${viewName}`);
    closeMenu();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => {
      drawAllCharts();
      const heading = $('h2', view);
      if (heading) {
        heading.tabIndex = -1;
        heading.focus({ preventScroll: true });
      }
    }, 50);
  }

  function openMenu() {
    $('#sidebar').classList.add('open');
    $('#mobileScrim').classList.add('show');
    $('#menuButton').setAttribute('aria-expanded', 'true');
  }

  function closeMenu() {
    $('#sidebar').classList.remove('open');
    $('#mobileScrim').classList.remove('show');
    $('#menuButton').setAttribute('aria-expanded', 'false');
  }

  function setupNavigation() {
    $$('.nav-item').forEach(item => item.addEventListener('click', () => navigate(item.dataset.view)));
    $$('[data-view-link]').forEach(item => item.addEventListener('click', () => navigate(item.dataset.viewLink)));
    $('#menuButton').addEventListener('click', () => $('#sidebar').classList.contains('open') ? closeMenu() : openMenu());
    $('#mobileScrim').addEventListener('click', closeMenu);
    document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
    const initialView = location.hash.slice(1);
    if ($(`[data-page="${initialView}"]`)) navigate(initialView, false);
    window.addEventListener('hashchange', () => {
      const requestedView = location.hash.slice(1);
      if ($(`[data-page="${requestedView}"]`)) navigate(requestedView, false);
    });
  }

  function setupCanvas(canvas) {
    if (!canvas || canvas.offsetParent === null) return null;
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const rect = canvas.getBoundingClientRect();
    const width = Math.max(280, rect.width);
    const height = Math.max(180, rect.height);
    canvas.width = width * ratio;
    canvas.height = height * ratio;
    const ctx = canvas.getContext('2d');
    ctx.scale(ratio, ratio);
    return { ctx, width, height };
  }

  function drawLineChart(canvas, values, labels, options = {}) {
    const setup = setupCanvas(canvas);
    if (!setup) return;
    const { ctx, width, height } = setup;
    const padArea = { left: 43, right: 16, top: 18, bottom: 31 };
    const plotW = width - padArea.left - padArea.right;
    const plotH = height - padArea.top - padArea.bottom;
    const max = options.max || Math.ceil(Math.max(...values, settings.threshold + 1) + .8);
    const min = 0;
    ctx.clearRect(0, 0, width, height);
    ctx.font = '10px "JetBrains Mono", "Cascadia Code", Consolas, monospace';
    ctx.textBaseline = 'middle';
    for (let i = 0; i <= 4; i++) {
      const y = padArea.top + plotH * i / 4;
      ctx.strokeStyle = 'rgba(148,163,184,.3)';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(padArea.left, y); ctx.lineTo(width - padArea.right, y); ctx.stroke();
      ctx.fillStyle = '#64748b';
      ctx.textAlign = 'right';
      ctx.fillText((max - (max - min) * i / 4).toFixed(1), padArea.left - 9, y);
    }
    if (options.threshold !== false) {
      const ty = padArea.top + plotH - (settings.threshold / max) * plotH;
      ctx.setLineDash([5, 5]); ctx.strokeStyle = 'rgba(181,107,21,.72)'; ctx.beginPath(); ctx.moveTo(padArea.left, ty); ctx.lineTo(width - padArea.right, ty); ctx.stroke(); ctx.setLineDash([]);
    }
    const points = values.map((value, i) => ({ x: padArea.left + plotW * i / Math.max(1, values.length - 1), y: padArea.top + plotH - ((value - min) / (max - min)) * plotH }));
    const gradient = ctx.createLinearGradient(0, padArea.top, 0, height - padArea.bottom);
    gradient.addColorStop(0, 'rgba(2,132,199,.18)'); gradient.addColorStop(1, 'rgba(2,132,199,0)');
    ctx.beginPath(); ctx.moveTo(points[0].x, height - padArea.bottom); points.forEach(p => ctx.lineTo(p.x, p.y)); ctx.lineTo(points.at(-1).x, height - padArea.bottom); ctx.closePath(); ctx.fillStyle = gradient; ctx.fill();
    ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)); ctx.strokeStyle = options.color || '#0273a8'; ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.stroke();
    const labelCount = Math.min(6, labels.length);
    ctx.fillStyle = '#64748b'; ctx.textAlign = 'center';
    for (let i = 0; i < labelCount; i++) {
      const index = Math.round(i * (labels.length - 1) / Math.max(1, labelCount - 1));
      ctx.fillText(labels[index], padArea.left + plotW * index / Math.max(1, labels.length - 1), height - 12);
    }
    canvas._chartPoints = points;
    canvas._chartValues = values;
    canvas._chartLabels = labels;
  }

  function drawBarChart(canvas, values, labels, options = {}) {
    const setup = setupCanvas(canvas);
    if (!setup) return;
    const { ctx, width, height } = setup;
    const area = { left: 43, right: 14, top: 16, bottom: 34 };
    const plotW = width - area.left - area.right;
    const plotH = height - area.top - area.bottom;
    const max = Math.ceil(Math.max(...values) * 1.18 / 10) * 10;
    ctx.clearRect(0, 0, width, height);
    ctx.font = '10px "JetBrains Mono", "Cascadia Code", Consolas, monospace';
    for (let i = 0; i <= 4; i++) {
      const y = area.top + plotH * i / 4;
      ctx.strokeStyle = 'rgba(148,163,184,.3)'; ctx.beginPath(); ctx.moveTo(area.left, y); ctx.lineTo(width - area.right, y); ctx.stroke();
      ctx.fillStyle = '#64748b'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle'; ctx.fillText(Math.round(max - max * i / 4).toLocaleString(), area.left - 8, y);
    }
    const slot = plotW / values.length;
    const barW = Math.min(options.wide ? 46 : 28, slot * .54);
    values.forEach((value, i) => {
      const x = area.left + slot * i + (slot - barW) / 2;
      const barH = value / max * plotH;
      const y = area.top + plotH - barH;
      const gradient = ctx.createLinearGradient(0, y, 0, area.top + plotH);
      gradient.addColorStop(0, options.color || '#0891b2'); gradient.addColorStop(1, options.colorEnd || 'rgba(8,145,178,.12)');
      roundedRect(ctx, x, y, barW, barH, 4); ctx.fillStyle = gradient; ctx.fill();
      ctx.fillStyle = '#64748b'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(labels[i], area.left + slot * i + slot / 2, height - 13);
    });
  }

  function roundedRect(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + width, y, x + width, y + height, r); ctx.arcTo(x + width, y + height, x, y + height, r); ctx.arcTo(x, y + height, x, y, r); ctx.arcTo(x, y, x + width, y, r); ctx.closePath();
  }

  function timeLabels(count = flowSeries.length) {
    return Array.from({ length: count }, (_, i) => {
      const d = new Date(virtualNow.getTime() - (count - 1 - i) * 75000);
      return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
    });
  }

  function drawAllCharts() {
    const labels = timeLabels();
    drawLineChart($('#flowChart'), flowSeries, labels);
    drawLineChart($('#flowChartLarge'), flowSeries, labels);
    drawBarChart($('#dailyChart'), dailyData, ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']);
    drawBarChart($('#monthlyChart'), monthlyData, ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug'], { color: '#526bc0', colorEnd: 'rgba(82,107,192,.12)' });
    updateAnalyticsChart();
  }

  function setupChartInteractions() {
    $('#flowChart').addEventListener('mousemove', event => {
      const canvas = event.currentTarget;
      const points = canvas._chartPoints || [];
      if (!points.length) return;
      const rect = canvas.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const index = points.reduce((best, point, i) => Math.abs(point.x - x) < Math.abs(points[best].x - x) ? i : best, 0);
      const tooltip = $('#flowTooltip');
      tooltip.hidden = false;
      tooltip.style.left = `${points[index].x + 13}px`;
      tooltip.style.top = `${points[index].y + 8}px`;
      tooltip.innerHTML = `<strong>${canvas._chartValues[index].toFixed(2)} L/min</strong><br>${canvas._chartLabels[index]}`;
    });
    $('#flowChart').addEventListener('mouseleave', () => $('#flowTooltip').hidden = true);
    $$('.range-control button').forEach(button => button.addEventListener('click', () => {
      $$('.range-control').forEach(control => $$('button', control).forEach(item => item.classList.toggle('active', item.textContent === button.textContent)));
      drawAllCharts();
    }));
    $$('#analyticsPeriod button').forEach(button => button.addEventListener('click', () => {
      $$('#analyticsPeriod button').forEach(item => item.classList.toggle('active', item === button));
      updateAnalyticsChart();
    }));
    $('#streamToggle')?.addEventListener('click', event => {
      streamPaused = !streamPaused;
      const button = event.currentTarget;
      button.setAttribute('aria-pressed', String(streamPaused));
      button.innerHTML = streamPaused
        ? `${svgIcon('i-play')}<span>Resume stream</span>`
        : `${svgIcon('i-pause')}<span>Pause stream</span>`;
      showToast(streamPaused ? 'Live telemetry paused on this screen.' : 'Live telemetry resumed.');
    });
  }

  function updateAnalyticsChart() {
    const canvas = $('#analyticsMainChart');
    if (!canvas || canvas.offsetParent === null) return;
    const period = $('#analyticsPeriod .active')?.dataset.period || 'daily';
    const configs = {
      daily: { values: dailyData, labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], kicker: 'Last 7 days', title: 'Daily consumption', color: '#0891b2' },
      weekly: { values: weeklyData, labels: ['W1','W2','W3','W4','W5','W6','W7','W8'], kicker: 'Last 8 weeks', title: 'Weekly consumption', color: '#0273a8' },
      monthly: { values: monthlyData, labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug'], kicker: 'Year to date', title: 'Monthly consumption', color: '#526bc0' }
    };
    const config = configs[period];
    $('#analyticsKicker').textContent = config.kicker; $('#analyticsTitle').textContent = config.title;
    drawBarChart(canvas, config.values, config.labels, { color: config.color, colorEnd: `${config.color}33`, wide: true });
  }

  function renderRecentReadings() {
    $('#recentReadings').innerHTML = readings.slice(0, 5).map(row => `<tr><td>${row.time}</td><td class="reading-flow">${row.flow.toFixed(2)} L/min</td><td>${row.usage.toFixed(1)} L</td><td>${statusBadge(row.status)}</td></tr>`).join('');
  }

  function renderRecentAlerts() {
    $('#recentAlerts').innerHTML = alerts.slice(0, 3).map(alert => `<div class="alert-item"><span class="alert-icon ${alert.severity}">${svgIcon('i-alert')}</span><span><strong>${alert.severity === 'critical' ? 'Possible leakage detected' : 'Continuous flow warning'}</strong><small>${alert.date} · ${alert.duration} · ${alert.loss}</small></span><small>${alert.status}</small></div>`).join('');
    $('#alertHistoryBody').innerHTML = alerts.map(alert => `<tr><td>${alert.date}</td><td>${alert.start}</td><td>${alert.end}</td><td>${alert.duration}</td><td class="reading-flow">${alert.loss}</td><td>${statusBadge(alert.status)}</td></tr>`).join('');
    updateNavAlertCount();
  }

  function filteredReadings() {
    const query = $('#tableSearch').value.trim().toLowerCase();
    const date = $('#dateFilter').value;
    const status = $('#statusFilter').value;
    return readings.filter(row => (!query || `${row.date} ${row.time} ${row.status} ${row.sensor}`.toLowerCase().includes(query)) && (!date || row.isoDate === date) && (status === 'all' || row.status === status)).sort((a, b) => sortDirection === 'desc' ? b.timestamp - a.timestamp : a.timestamp - b.timestamp);
  }

  function renderHistory() {
    const filtered = filteredReadings();
    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    currentPage = Math.min(currentPage, pages);
    const start = (currentPage - 1) * pageSize;
    $('#historyBody').innerHTML = filtered.slice(start, start + pageSize).map(row => `<tr><td><strong>${row.date}</strong><br><small>${row.time} MYT</small></td><td>${row.sensor}</td><td class="reading-flow">${row.flow.toFixed(2)} L/min</td><td>${row.usage.toFixed(1)} L</td><td>${statusBadge(row.status)}</td></tr>`).join('') || `<tr><td colspan="5">No sensor records match these filters.</td></tr>`;
    $('#paginationSummary').textContent = filtered.length ? `Showing ${start + 1}–${Math.min(start + pageSize, filtered.length)} of ${filtered.length} readings` : 'No readings found';
    $('#prevPage').disabled = currentPage === 1; $('#nextPage').disabled = currentPage === pages;
    $('#pageButtons').innerHTML = Array.from({ length: pages }, (_, i) => i + 1).slice(Math.max(0, currentPage - 3), currentPage + 2).map(page => `<button class="${page === currentPage ? 'active' : ''}" data-page-number="${page}" aria-label="Page ${page}">${page}</button>`).join('');
    $$('[data-page-number]').forEach(button => button.addEventListener('click', () => { currentPage = +button.dataset.pageNumber; renderHistory(); }));
  }

  function setupHistory() {
    ['tableSearch','dateFilter','statusFilter'].forEach(id => $(`#${id}`).addEventListener('input', () => { currentPage = 1; renderHistory(); }));
    $('#clearFilters').addEventListener('click', () => { $('#tableSearch').value = ''; $('#dateFilter').value = ''; $('#statusFilter').value = 'all'; currentPage = 1; renderHistory(); });
    $('#prevPage').addEventListener('click', () => { if (currentPage > 1) { currentPage--; renderHistory(); } });
    $('#nextPage').addEventListener('click', () => { currentPage++; renderHistory(); });
    $('[data-sort="timestamp"]').addEventListener('click', () => { sortDirection = sortDirection === 'desc' ? 'asc' : 'desc'; renderHistory(); });
    $('#historyExport').addEventListener('click', exportCsv);
    $('#exportButton').addEventListener('click', exportCsv);
  }

  function exportCsv() {
    const rows = [['Date','Time','Sensor','Flow Rate (L/min)','Water Usage (L)','Leakage Status'], ...filteredReadings().map(row => [row.date,row.time,row.sensor,row.flow,row.usage,row.status])];
    const csv = rows.map(row => row.map(value => `"${String(value).replaceAll('"','""')}"`).join(',')).join('\r\n');
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    link.download = 'smart-water-readings-2026-08-27.csv';
    link.click(); URL.revokeObjectURL(link.href);
    showToast('Sensor data exported as CSV.');
  }

  function loadSettingsForm() {
    $('#flowThreshold').value = settings.threshold;
    $('#flowDuration').value = settings.duration;
    $('#detectionEnabled').checked = settings.detection;
    $('#alertsEnabled').checked = settings.alerts;
    updateSettingLabels();
  }

  function updateSettingLabels() {
    $('#thresholdDisplay').textContent = `${Number(settings.threshold).toFixed(1)} L/min`;
    $('#durationDisplay').textContent = `${settings.duration} minutes`;
  }

  function setupSettings() {
    loadSettingsForm();
    $('#settingsForm').addEventListener('submit', event => {
      event.preventDefault();
      settings.threshold = +$('#flowThreshold').value;
      settings.duration = +$('#flowDuration').value;
      settings.detection = $('#detectionEnabled').checked;
      settings.alerts = $('#alertsEnabled').checked;
      localStorage.setItem('smartWaterSettings', JSON.stringify(settings));
      updateSettingLabels(); drawAllCharts(); showToast('Detection settings saved successfully.');
    });
    $('#resetSettings').addEventListener('click', () => {
      Object.assign(settings, { threshold: 1, duration: 10, detection: true, alerts: true });
      localStorage.setItem('smartWaterSettings', JSON.stringify(settings)); loadSettingsForm(); drawAllCharts(); showToast('Default settings restored.');
    });
  }

  function updateTelemetry() {
    if (streamPaused) return;
    if (dataSource === 'firebase') {
      return;
    }
    virtualNow = new Date(virtualNow.getTime() + 5000);
    secondsSinceReading = 0;
    const previous = currentFlow;
    const target = 3.7 + Math.sin(virtualNow.getTime() / 30000) * .75 + (Math.random() - .5) * .35;
    currentFlow = Math.max(0, Math.min(6.2, previous * .55 + target * .45));
    todayUsage += currentFlow / 12;
    monthUsage += currentFlow / 12;
    flowSeries.shift(); flowSeries.push(+currentFlow.toFixed(2));
    const row = {
      id: readings[0].id + 1, sensor: 'YF-S201', timestamp: new Date(virtualNow),
      date: `${pad(virtualNow.getDate())}/${pad(virtualNow.getMonth() + 1)}/${virtualNow.getFullYear()}`,
      isoDate: `${virtualNow.getFullYear()}-${pad(virtualNow.getMonth() + 1)}-${pad(virtualNow.getDate())}`,
      time: `${pad(virtualNow.getHours())}:${pad(virtualNow.getMinutes())}:${pad(virtualNow.getSeconds())}`,
      flow: +currentFlow.toFixed(2), usage: +(currentFlow / 12).toFixed(1), status: 'Normal'
    };
    readings.unshift(row);
    updateTelemetryDom(previous); renderRecentReadings(); renderHistory(); drawAllCharts();
  }

  function updateTelemetryDom(previous) {
    const flowText = currentFlow.toFixed(2);
    $('#currentFlow').textContent = flowText; $('#chartCurrent').textContent = flowText; updateUsageDisplay();
    $('#flowDelta').textContent = `${currentFlow - previous >= 0 ? '+' : ''}${(currentFlow - previous).toFixed(2)}`;
    $('#rtFlow').textContent = `${flowText} L/min`; $('#rtTimestamp').textContent = `${pad(virtualNow.getHours())}:${pad(virtualNow.getMinutes())}:${pad(virtualNow.getSeconds())}`;
    $('#leakFlow').textContent = `${flowText} L/min`; $('#systemFlow').textContent = `${flowText} L/min`;
    $('#lastTimestamp').textContent = `${pad(virtualNow.getDate())} Aug 2026, ${pad(virtualNow.getHours())}:${pad(virtualNow.getMinutes())}:${pad(virtualNow.getSeconds())} MYT`;
  }

  function updateRelativeTime() {
    if (streamPaused) return;
    secondsSinceReading++;
    const label = secondsSinceReading < 2 ? 'just now' : `${secondsSinceReading} seconds ago`;
    $('#lastUpdatedHeader').textContent = label; $('#lastReceived').textContent = label;
    if (secondsSinceReading > 30) setOfflineState();
  }

  function setOfflineState() {
    $('#lastUpdatedHeader').textContent = 'Gateway offline';
    $('.connection-pill strong').textContent = 'OFFLINE';
    $('.connection-pill strong').className = 'text-critical';
  }

  function applyFirebasePayload(records) {
    if (streamPaused) return;
    if (!Array.isArray(records) || !records.length) return;
    const previous = currentFlow;
    const mapped = records.map(item => {
      const rawTimestamp = item.timestamp ?? item.created_at;
      const stamp = typeof rawTimestamp === 'number'
        ? new Date(rawTimestamp)
        : new Date(String(rawTimestamp || '').replace(' ', 'T'));
      return {
        id: item.id, sensor: item.sensor_name || item.sensorName || 'YF-S201', timestamp: stamp,
        date: `${pad(stamp.getDate())}/${pad(stamp.getMonth() + 1)}/${stamp.getFullYear()}`,
        isoDate: `${stamp.getFullYear()}-${pad(stamp.getMonth() + 1)}-${pad(stamp.getDate())}`,
        time: `${pad(stamp.getHours())}:${pad(stamp.getMinutes())}:${pad(stamp.getSeconds())}`,
        flow: Number(item.flow_rate ?? item.flowRate ?? 0),
        usage: Number(item.water_usage ?? item.waterUsage ?? 0),
        rawTotal: Number(item.total_litres ?? item.totalLitres ?? item.water_usage ?? item.waterUsage ?? 0),
        rawMonthly: Number(item.monthly_litres ?? item.monthlyLitres ?? 0),
        baselineFlow: Number(item.baseline_flow_rate ?? item.baselineFlowRate ?? 0),
        status: item.leakage_status ?? item.leakageStatus ?? 'Normal'
      };
    }).filter(item => !Number.isNaN(item.timestamp.getTime())).sort((a, b) => a.timestamp - b.timestamp);
    if (!mapped.length) return;

    const latest = mapped.at(-1);
    const todayKey = `${latest.timestamp.getFullYear()}-${pad(latest.timestamp.getMonth() + 1)}-${pad(latest.timestamp.getDate())}`;
    const monthKey = todayKey.slice(0, 7);
    const dayRecords = mapped.filter(item => item.isoDate === todayKey);
    const firstDayRecord = dayRecords[0] || latest;
    if (!usageResetState.today || usageResetState.today.date !== todayKey) {
      usageResetState.today = { date: todayKey, raw: firstDayRecord.rawTotal, manual: false };
      persistUsageResets();
    }
    if (!usageResetState.month || usageResetState.month.key !== monthKey) {
      // monthly_litres is already a cumulative month total from the ESP32;
      // keep the real total until the user explicitly creates a new baseline.
      usageResetState.month = { key: monthKey, raw: 0, manual: false };
      persistUsageResets();
    }
    latestFirebaseUsage = {
      timestamp: latest.timestamp,
      dayKey: todayKey,
      monthKey,
      rawTotal: latest.rawTotal,
      rawMonthly: latest.rawMonthly
    };
    currentFlow = latest.flow;
    applyLeakageStatus(latest.status);
    $('#baselineFlow').textContent = latest.baselineFlow > 0 ? `${latest.baselineFlow.toFixed(2)} L/min` : 'Learning';
    todayUsage = Math.max(0, latest.rawTotal - Number(usageResetState.today.raw || 0));
    monthUsage = Math.max(0, latest.rawMonthly - Number(usageResetState.month.raw || 0));
    if (!Number.isFinite(monthUsage) || monthUsage === 0 && latest.rawMonthly === 0) {
      monthUsage = Math.max(0, latest.rawTotal - Number(usageResetState.month.raw || 0));
    }
    dailyData[dailyData.length - 1] = todayUsage;
    monthlyData[monthlyData.length - 1] = monthUsage;
    readings.splice(0, readings.length, ...[...mapped].reverse());
    const latestSeries = mapped.slice(-48).map(item => item.flow);
    if (latestSeries.length > 1) flowSeries.splice(0, flowSeries.length, ...latestSeries);
    const latestStamp = readings[0]?.timestamp;
    if (latestStamp) virtualNow = new Date(latestStamp);
    secondsSinceReading = latestStamp ? Math.max(0, Math.floor((Date.now() - latestStamp.getTime()) / 1000)) : 0;
    updateTelemetryDom(previous);
    renderRecentReadings(); renderHistory(); drawAllCharts();
  }

  function applyFirebaseAlerts(records) {
    if (!Array.isArray(records) || !records.length) return;
    const mapped = records.map(item => {
      const start = new Date(item.started_at ?? item.timestamp ?? Date.now());
      const end = item.ended_at ? new Date(item.ended_at) : null;
      const seconds = Number(item.duration_seconds ?? 0);
      return {
        date: `${pad(start.getDate())}/${pad(start.getMonth() + 1)}/${start.getFullYear()}`,
        start: `${pad(start.getHours())}:${pad(start.getMinutes())}:${pad(start.getSeconds())}`,
        end: end ? `${pad(end.getHours())}:${pad(end.getMinutes())}:${pad(end.getSeconds())}` : 'Active',
        duration: `${Math.floor(seconds / 60)} min ${seconds % 60} sec`,
        loss: `${Number(item.estimated_water_loss ?? 0).toFixed(1)} L`,
        status: item.status ?? 'Needs review',
        severity: item.status === 'Resolved' ? 'warning' : 'critical'
      };
    }).reverse();
    alerts.splice(0, alerts.length, ...mapped);
    renderRecentAlerts();
  }

  function setupFirebaseEvents() {
    const config = window.SMART_WATER_FIREBASE_CONFIG || {};
    const configured = ['apiKey', 'authDomain', 'databaseURL', 'projectId', 'appId']
      .every(key => config[key] && !String(config[key]).includes('REPLACE_WITH'));
    $('#databaseDetail').textContent = configured ? 'Connecting to Firebase' : 'Firebase setup required';
    $('#systemDbMode').textContent = configured ? 'Connecting' : 'Demo fallback';
    $('#firebaseConnection').textContent = configured ? 'Connecting' : 'Not configured';

    const setBadges = (state, label) => {
      ['firebaseStatusBadge', 'firebaseSystemBadge'].forEach(id => {
        const badge = $(`#${id}`);
        if (!badge) return;
        badge.className = `status-text ${state}`;
        badge.innerHTML = `<i></i>${label}`;
      });
    };
    setBadges('warning', configured ? 'Connecting' : 'Setup required');

    window.addEventListener('smartwater:firebase-status', event => {
      const state = event.detail || {};
      if (!state.configured) {
        dataSource = 'mock';
        $('#databaseDetail').textContent = 'Firebase setup required';
        $('#systemDbMode').textContent = 'Demo fallback';
        $('#firebaseConnection').textContent = 'Not configured';
        setBadges('warning', 'Setup required');
        return;
      }
      dataSource = state.connected ? 'firebase' : dataSource;
      $('#databaseDetail').textContent = state.message || 'Firebase Realtime Database';
      $('#systemDbMode').textContent = state.connected ? 'Firebase live' : 'Reconnecting';
      $('#firebaseConnection').textContent = state.connected ? 'Connected' : 'Reconnecting';
      setBadges(state.connected ? 'online' : 'warning', state.connected ? 'Connected' : 'Reconnecting');
    });

    window.addEventListener('smartwater:firebase-readings', event => {
      dataSource = 'firebase';
      applyFirebasePayload(event.detail?.records || []);
    });

    window.addEventListener('smartwater:firebase-alerts', event => {
      applyFirebaseAlerts(event.detail?.records || []);
    });
  }

  let resizeTimer;
  window.addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(drawAllCharts, 120); });

  setupFirebaseEvents();
  setupNavigation();
  setupChartInteractions();
  setupUsageResets();
  setupHistory();
  setupSettings();
  renderRecentReadings();
  renderRecentAlerts();
  renderHistory();
  updateUsageDisplay();
  drawAllCharts();
  setInterval(updateRelativeTime, 1000);
  setInterval(updateTelemetry, 5000);
})();
