# Smart Water Monitoring

A responsive IoT dashboard for an ESP32 and YF-S201 water-flow sensor. Firebase Realtime Database is the primary backend, allowing the website to be deployed on InfinityFree without Node-RED, MQTT, PHP APIs, or a remotely accessible MySQL server.

## Architecture

```text
YF-S201 → ESP32 → Firebase Realtime Database → InfinityFree dashboard
                 ↘ Telegram leakage alert
```

The dashboard listens to Firebase changes in real time. Until Firebase is configured, it automatically runs with realistic demonstration telemetry.

## Firebase setup

1. Create a Firebase project and register a Web app.
2. Create a Realtime Database, preferably in the Singapore region.
3. Enable **Authentication → Sign-in method → Anonymous** for the dashboard and ESP32.
4. Copy the Firebase Web configuration into `assets/js/firebase-config.js`.
5. Paste and publish `firebase/database.rules.json` through the Realtime Database Rules screen.
6. Optionally import `firebase/sample-data.json` for initial test readings.

Detailed instructions and the expected ESP32 payload are in `firebase/README.md`.
Firmware, library requirements, and secret configuration are in `esp32/README.md`.

## Run locally

Start Apache in Laragon, then open:

```text
http://localhost/IOT%20Based%20Smart%20water%20Consumption%20and%20leakage%20detection/
```

The Firebase SDK is loaded as an official modular browser module from Google's CDN. No npm build step is required.

## Deploy to InfinityFree

Upload these items into the InfinityFree `htdocs` directory:

```text
index.php
assets/
```

Firebase communicates directly from the visitor's browser, so the old PHP API and MySQL schema are not required on InfinityFree. Keep `firebase/database.rules.json` locally as deployment documentation; publish those rules in Firebase Console rather than uploading them as a public website file.

## Security

- The Firebase Web configuration is a public project identifier, not a private server key.
- Never upload a Firebase service-account JSON file, Wi-Fi password, or Telegram bot token to InfinityFree.
- Do not leave Realtime Database in test mode.
- The simplified rules use Firebase Anonymous Authentication for both reading and writing telemetry. This is convenient for prototypes, but a dedicated writer account or device UID rule is safer for production.

## Legacy prototype files

The `api/`, `config/`, and `database/` folders are retained only as reference for the earlier PHP/MySQL prototype. The dashboard and firmware no longer call them at runtime.
